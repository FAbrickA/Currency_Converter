package com.example.currencyconverter

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

import org.jsoup.Jsoup
import java.text.DecimalFormat
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity() {

    lateinit var secThread: Thread
    lateinit var runable: Runnable

    var ruble = 1.0
    var dollar = 68.49
    var euro = 77.34
    var kopeck = 2.58
    var pound = 86.75

    var rubleText = "Рубль"
    var dollarText = "Доллар"
    var euroText = "Евро"
    var kopeckText = "Гривна"
    var poundText = "Фунт"

    var CurrencyText1 = rubleText
    var CurrencyText2 = dollarText
    var CurrencyValue1 = ruble
    var CurrencyValue2 = dollar
    var CurrencyNumber = 1.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setFirst(radio_group_first)
        setSecond(radio_group_second)
        init()
//        Toast.makeText(this, "$this!", Toast.LENGTH_LONG).show()
    }

    fun init() {
        runable = Runnable {
            val siteName: String = "https://www.cbr-xml-daily.ru/daily_utf8.xml"
            fun run() {
                fun calcElemRate(element: org.jsoup.nodes.Element): Double {
                    var value = element.getElementsByTag("Value")[0].text()
                        .replace(",", ".").toDouble()
                    val nominal = element.getElementsByTag("Nominal")[0].text()
                        .replace(",", ".").toDouble()
                    value /= nominal
                    return value
                }
                Looper.prepare()
//                runOnUiThread(Runnable {Toast.makeText(this,
//                    "Начало загрузки котировок...", Toast.LENGTH_SHORT).show()})
                val webDoc: org.jsoup.nodes.Document
                try {
                    webDoc = Jsoup.connect(siteName).get()
                } catch (e: Exception){
                    runOnUiThread(Runnable {Toast.makeText(this,
                            "Не удаётся получить данные из сети", Toast.LENGTH_SHORT).show()})
                    return
                }
                val allCurrency = webDoc.getElementsByTag("Valute")
                println(allCurrency[0])
                allCurrency.forEach {
                    val charText = it.getElementsByTag("CharCode")[0].text()
                    if (charText == "USD") {
                        dollar = calcElemRate(it)
                    } else if (charText == "EUR") {
                        euro = calcElemRate(it)
                    } else if (charText == "UAH") {
                        kopeck = calcElemRate(it)
                    } else if (charText == "GBP") {
                        pound = calcElemRate(it)
                    } else if (charText == "RUB") {
                        ruble = calcElemRate(it)
                    }
                }
                runOnUiThread(Runnable { updateCurse()
                    Toast.makeText(this,
                    "Котировки успешно загружены!", Toast.LENGTH_SHORT).show()})
            }
            run()
        }
        secThread = Thread(runable)
        secThread.start()
    }

    fun updateCurse() {
        if (CurrencyText1 == rubleText) CurrencyValue1 = ruble
        else if (CurrencyText1 == dollarText) CurrencyValue1 = dollar
        else if (CurrencyText1 == euroText) CurrencyValue1 = euro
        else if (CurrencyText1 == kopeckText) CurrencyValue1 = kopeck
        else if (CurrencyText1 == poundText) CurrencyValue1 = pound

        if (CurrencyText2 == rubleText) CurrencyValue2 = ruble
        else if (CurrencyText2 == dollarText) CurrencyValue2 = dollar
        else if (CurrencyText2 == euroText) CurrencyValue2 = euro
        else if (CurrencyText2 == kopeckText) CurrencyValue2 = kopeck
        else if (CurrencyText2 == poundText) CurrencyValue2 = pound

        changeCurseHeading()
    }

    fun ruble_set(num: Int) {
        if (num == 1) {
            CurrencyText1 = rubleText
            CurrencyValue1 = ruble
        } else {
            CurrencyText2 = rubleText
            CurrencyValue2 = ruble
        }
    }

    fun dollar_set(num: Int) {
        if (num == 1) {
            CurrencyText1 = dollarText
            CurrencyValue1 = dollar
        } else {
            CurrencyText2 = dollarText
            CurrencyValue2 = dollar
        }
    }

    fun pound_set(num: Int) {
        if (num == 1) {
            CurrencyText1 = poundText
            CurrencyValue1 = pound
        } else {
            CurrencyText2 = poundText
            CurrencyValue2 = pound
        }
    }

    fun euro_set(num: Int) {
        if (num == 1) {
            CurrencyText1 = euroText
            CurrencyValue1 = euro
        } else {
            CurrencyText2 = euroText
            CurrencyValue2 = euro
        }
    }

    fun kopeck_set(num: Int) {
        if (num == 1) {
            CurrencyText1 = kopeckText
            CurrencyValue1 = kopeck
        } else {
            CurrencyText2 = kopeckText
            CurrencyValue2 = kopeck
        }
    }

    fun setFirst(view: View) {
        val myCounter = 1
        radio_group_first.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.ruble_first -> {
                    ruble_set(myCounter)
                }
                R.id.dollar_first -> {
                    dollar_set(myCounter)
                }
                R.id.euro_first -> {
                    euro_set(myCounter)
                }
                R.id.kopeck_first -> {
                    kopeck_set(myCounter)
                }
                R.id.pound_first -> {
                    pound_set(myCounter)
                }
            }
        }
        changeCurseHeading()
    }

    fun setSecond(view: View) {
        val myCounter = 2
        radio_group_second.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.ruble_second -> {
                    ruble_set(myCounter)
                }
                R.id.dollar_second -> {
                    dollar_set(myCounter)
                }
                R.id.euro_second -> {
                    euro_set(myCounter)
                }
                R.id.kopeck_second -> {
                    kopeck_set(myCounter)
                }
                R.id.pound_second -> {
                    pound_set(myCounter)
                }
            }
        }
        changeCurseHeading()
    }

    @SuppressLint("SetTextI18n")
    fun changeCurseHeading() {
        val rate = CurrencyValue1 / CurrencyValue2
        val rateText: String = getValueText(rate * CurrencyNumber)
        curse_heading.text = "${getValueText(CurrencyNumber)} $CurrencyText1 = \n" +
                "$rateText $CurrencyText2"
    }

    fun getValueText(num: Double): String {
        val df = DecimalFormat("#.###");
        return if (num == num.roundToLong().toDouble()) {
            num.roundToLong().toString()
        } else {
            df.format(num).toString()

        }
    }

    fun showCurse(view: View) {
        CurrencyNumber = 1.0
        changeCurseHeading()
    }

    fun setNewCurrencyNumber(view: View) {
        val text: String = currencyNumberInput.text.toString()
        val num: Double
        if (text == "") {
            Toast.makeText(this, "Введите кол-во валюты", Toast.LENGTH_SHORT).show()
        } else {
            try {
                num = text.toDouble()
                CurrencyNumber = num
                changeCurseHeading()
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Некорректное число", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
